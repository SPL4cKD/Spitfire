// STAR-CCM+ macro: meshrun.java
package macro;

import java.util.*;

import star.common.*;
import star.base.neo.*;
import star.meshing.*;

public class meshrun extends StarMacro {

  public void execute() {
    execute0();
  }

  private void execute0() {

    Simulation simulation_0 = 
      getActiveSimulation();

    MeshPipelineController meshPipelineController_0 = 
      simulation_0.get(MeshPipelineController.class);

    meshPipelineController_0.generateVolumeMesh();

    ResidualPlot residualPlot_0 = 
      ((ResidualPlot) simulation_0.getPlotManager().getObject("Residuals"));

    residualPlot_0.setTitleFont(new java.awt.Font("SansSerif", 0, 12));

    simulation_0.getSimulationIterator().run();
  }
}
